# AutoScalePro – Scalable AWS Infrastructure with Terraform

## Overview
This project provisions a modular, scalable AWS infrastructure using Terraform. It includes EC2, VPC, IAM, S3, and CloudWatch alarms with support for remote state management.

## Features
- Modularized Terraform code for each component
- S3 remote state backend and DynamoDB locking
- Public subnet and EC2 instance provisioning
- IAM instance profile and policies
- CloudWatch CPU alarms
- Outputs for resource tracking

## Folder Structure
```
autoscalepro-pro/
├── main.tf
├── variables.tf
├── outputs.tf
├── terraform.tfvars
├── modules/
│   ├── vpc/
│   ├── ec2/
│   ├── iam/
│   ├── s3/
│   └── cloudwatch/
```

## Setup Instructions

### Prerequisites
- AWS CLI configured (`aws configure`)
- Terraform v1.0+

### Deployment Steps
```bash
terraform init
terraform plan -var-file="terraform.tfvars"
terraform apply -var-file="terraform.tfvars"
```

### Cleanup
```bash
terraform destroy -var-file="terraform.tfvars"
```

## Notes
- Ensure the backend S3 bucket and DynamoDB table exist for state locking.
- Customize variables and resources as needed for your environment.